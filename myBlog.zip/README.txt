-Configurer un ficher dbconf.php dans config avec la base de donn�e en suivant l'exemple de dbcong.php.dist
-Le vhost pointe sur le dossier view
-Pour se connecter, il est possible d'utiliser l'identifiant suivant: "root", "root42"

La base de donn�e contient 2 tables:
	-article avec id, title, content, imag, et author_name
	-users avec id, pseudo, password, mail,	lastname, firstname, birthdate
