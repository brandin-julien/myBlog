<?php
$config = [
    "host" => "mysql:host=127.0.0.1;dbname=myblog",
    "user" => "root",
    "password" => "",
];